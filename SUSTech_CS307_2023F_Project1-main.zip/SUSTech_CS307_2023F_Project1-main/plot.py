import matplotlib
import matplotlib.pyplot as plt
import numpy as np


labels = ['1k', '10k','37k']
a = [1.595,1.595,1.595]
b = [0.065, 0.154, 0.280]
c = [0.945, 1.008, 1.314]

x = np.arange(len(labels))
width = 0.3

fig, ax = plt.subplots()
rects1 = ax.bar(x - width, a, width, label='File IO')
rects2 = ax.bar(x, b, width, label='DBMS')
rects3 = ax.bar(x + width, c, width, label='DBMS Parallel')
ax.bar_label(rects1, padding=2)
ax.bar_label(rects2, padding=2)
ax.bar_label(rects3, padding=2)

ax.set_ylabel('Time/s')
ax.set_title('Query Cost')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()
plt.show()
